https://stackoverflow.com/questions/69047803/take-an-element-from-a-list-and-assign-it-to-a-variable
https://stackoverflow.com/questions/455612/limiting-floats-to-two-decimal-points
https://iq.opengenus.org/terminate-program-in-python/
https://researchdatapod.com/python-valueerror-too-many-values-to-unpack-expected-2/
https://stackoverflow.com/questions/23294658/asking-the-user-for-input-until-they-give-a-valid-response